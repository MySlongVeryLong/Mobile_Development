import 'models/expense.dart';

void main() {
  Expense e1 = Expense(
    amount: 10,
    title: "piano",
    category: Category.leisure,
    date: DateTime.now(),
  );

  print(e1);
}
